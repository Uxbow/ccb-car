function openModal(){
    document.getElementById('conditions-location').classList.add('poppedUp');
    setTimeout(()=>{
        document.getElementById('conditions-location').querySelector('.modal-content').classList.add('displayed');
    },300)
}

document.querySelector('.modal').addEventListener('click',(ele)=>{
    if(ele.target === document.querySelector('.modal-content') || ele.target.tagName ==='P' || ele.target.tagName ==='H3'){
        return;
}
document.getElementById('conditions-location').querySelector('.modal-content').classList.remove('displayed');
setTimeout(()=>{
    document.getElementById('conditions-location').classList.remove('poppedUp');
},450)
})